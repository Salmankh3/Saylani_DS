from django.http import HttpResponse
from django.shortcuts import render

def index(request):

    fname = request.GET.get("firstname")
    lname = request.GET.get("lastname")
    fullname = f"{fname} {lname}"
    data = {'fullname':fullname}

    return render(request,'index.html',data)

