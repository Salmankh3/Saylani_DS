from django.apps import AppConfig


class PythoncourseConfig(AppConfig):
    name = 'pythonCourse'
